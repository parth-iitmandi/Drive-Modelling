Rs = 4.9 %Ohm (Stator per-phase resistance)
Rr_= 8.1 %Ohm (Rotor per-phase resistance)
Lls = 32.15e-3 %H (Stator leakage inductance)
Llr_ = 32.15e-3 %H (Rotor leakage inductance)
M = 809.6e-3 %H (Magnetizing inductance)
J = 0.013 %kg-m^2 (Inertia)
P = 2 %Poles of the SCIM
B = 0 %Nms Viscous Friction