% Assignment 2 Q3 Modeling of DC Machine
Ra=0.6; % Ohms ( Armature Resistance)
La=0.012; % H (Armature Inductance)
Rf=120; % Ohm ( Field Resistance)
Lf=120; % H (Fielf Resistance)
Va=240; % V (Armature and field rated voltage)
Ia=10; % A ( Rated armature current)
N=1200; % rpm ( Rated Speed)
Wm=(2*pi*N)/60; %rad/sec ( Rated Speed)
J=1; %Kg m^2 (motor + load Inertia)
If=2; % A (Rated Field Current)
TL=18.6;  % Nm (Load Torque)(It is taken such a way that rated current flows through machine at rated voltage)

%Calculation of Motor Constant Km
% Ea=Va-Ia*Ra=Km*If*Wm

Km=(Va-Ia*Ra)/(If*Wm);
open('parthQ3block');
sim('parthQ3block');